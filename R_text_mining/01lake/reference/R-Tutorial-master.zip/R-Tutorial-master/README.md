# R-Tutorial
Codes for channel "R语千寻" in the BearAcademy.
- Lecture 1: 用R做柱状图：2016，哪些明星最忙？
- Lecture 2: 也谈 ggplot2
- Lecture 3: 张无忌究竟爱谁？
